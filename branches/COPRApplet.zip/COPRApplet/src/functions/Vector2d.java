package functions;

public class Vector2d {
	public double x;
	public double y;
	
	public Vector2d(double xx, double yy)
	{
		x=xx;
		y=yy;
	}
	
	public Vector2d()
	{
		x=0;
		y=0;
	}
}
