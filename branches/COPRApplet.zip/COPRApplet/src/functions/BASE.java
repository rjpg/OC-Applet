package functions;

import javax.swing.JTabbedPane;

public class BASE {
	public static String orderTo="t"; 
	public static String matServerIP="whale.fe.up.pt";
	public static int matPort=80;
	public static String matJWS="/coapplet/matlinkws/Matlink.jws";
	public static JTabbedPane tabbed =new JTabbedPane();
	public static boolean active=false;
}
