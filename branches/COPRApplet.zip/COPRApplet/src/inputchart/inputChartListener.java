package inputchart;

public interface inputChartListener {
	public void change(InputChart chart);
}
